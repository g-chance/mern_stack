const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost/mytestdb10', {useNewUrlParser:true, useUnifiedTopology:true});
